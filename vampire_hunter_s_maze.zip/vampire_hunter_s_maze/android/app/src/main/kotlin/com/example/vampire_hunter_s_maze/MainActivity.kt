package com.example.vampire_hunter_s_maze

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
